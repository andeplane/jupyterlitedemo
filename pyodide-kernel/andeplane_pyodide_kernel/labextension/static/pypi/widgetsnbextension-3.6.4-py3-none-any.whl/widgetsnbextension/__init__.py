"""A widgetsnbextension mock"""

__version__ = "3.6.4"
